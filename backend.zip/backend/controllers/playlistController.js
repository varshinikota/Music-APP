import mongodb from "mongodb";
import conn from "../config/db.js";

// @desc   add new playlist
// @route  POST /api/v1/playlist/create
// @access Private
export const addPlaylist = async (req, res) => {
  try {
    // Establishing connection to the database
  
    const db = conn.db("music_streaming");
    const collection = db.collection("playlists");

    //Inserting the playlist to the database
    const playList = await collection.insertOne({
      playlistName: req.body.playlistName,
      createdBy: req.userId,
      songs: [],
    });
    
    


    // If the playlist is added successfully return a success message
    if (playList) {
      return res
        .status(200)
        .json({ message: "Playlist added successfully", status: "success" });
    
    } else throw new Error("Error adding playlist");
  } catch (error) {
    console.log(error);
    return res.status(500).json({ error: error.message, status: "error" });
  }
};

// @desc   Delete a playlist
// @route  DELETE /api/v1/playlist/delete/:id
// @access Private


// export const deletePlaylist = async (req, res) => {
//   try {

//     const db = conn.db("music_streaming");
//     const collection = db.collection("playlists");

//     const playlist = await collection.deleteOne({
//       _id: new mongodb.ObjectId(req.params.id),
//     });
//     if (playlist) {
//       return res
//         .status(200)
//         .json({ message: "Playlist deleted successfully", status: "success" });
//     } else throw new Error("Error deleting playlist");
//   } catch (error) {
//     console.log(error.message);
//     return res.json({ error: error.message, status: "error" });
//   }
// };



export const deletePlaylist = async (req, res) => {
  try {
    // Validate ObjectId
    if (!mongodb.ObjectId.isValid(req.params.id)) {
      return res.status(400).json({ error: "Invalid playlist ID", status: "error" });
    }

    const db = conn.db("music_streaming");
    const collection = db.collection("playlists");

    const result = await collection.deleteOne({
      _id: new mongodb.ObjectId(req.params.id),
    });

    if (result.deletedCount === 0) {
      return res.status(404).json({ error: "Playlist not found", status: "error" });
    }

    res.status(200).json({ message: "Playlist deleted successfully", status: "success" });
  } catch (error) {
    console.error("Delete playlist error:", error);
    res.status(500).json({ error: "Internal server error", status: "error" });
  }
};




// @desc   Add song to playlist
// @route  POST /api/v1/playlist/add/:id
// @access Private
export const addSongToPlaylist = async (req, res) => {
  try {
    
    const db = conn.db("music_streaming");
    const collection = db.collection("playlists");

    const playlist = await collection.findOneAndUpdate(
      { _id: new mongodb.ObjectId(req.params.id) },
      { $push: { songs: req.body[0] } }
    );
    if (playlist) {
      return res
        .status(200)
        .json({ message: "Song added to playlist", status: "success" });
    } else throw new Error("Error adding song to playlist");
  } catch (error) {
    console.log(error);
    return res.status(500).json({ error: error.message, status: "error" });
  }
  res.send("Add Song to Playlist Page");
};

// @desc   Remove song from playlist
// @route  DELETE /api/v1/playlist/remove/:id
// @access Private
// export const removeSongFromPlaylist = async (req, res) => {
//   try {
   
//     const db = conn.db("music_streaming");
//     const collection = db.collection("playlists");

//     const playlist = await collection.findOneAndUpdate(
//       { _id: new mongodb.ObjectId(req.params.id) },
//       { $pull: { songs: { title: req.query.song } } }
//     );
//     res.status(200).json({ message: "Song removed from playlist" });
//   } catch (error) {
//     console.log(error);
//     return res.json({ error: error.message, status: "error" });
//   }
// };


export const removeSongFromPlaylist = async (req, res) => {
  try {
    const { id } = req.params;
    const { song } = req.query;

    // Validate inputs
    if (!id || !song) {
      return res.status(400).json({ error: "Playlist ID and song title are required", status: "error" });
    }

    // Validate ObjectId
    if (!mongodb.ObjectId.isValid(id)) {
      return res.status(400).json({ error: "Invalid playlist ID", status: "error" });
    }

    // Check if userId is set
    if (!req.userId) {
      return res.status(401).json({ error: "User authentication required", status: "error" });
    }

    const db = conn.db("music_streaming");
    const collection = db.collection("playlists");

    console.log("Removing song:", { id, song, userId: req.userId }); // Debug

    // Check if playlist exists and user has permission
    const playlist = await collection.findOne({ _id: new mongodb.ObjectId(id) });
    console.log("Playlist found:", playlist); // Debug

    if (!playlist) {
      return res.status(404).json({ error: "Playlist not found", status: "error" });
    }

    if (playlist.createdBy !== req.userId) {
      return res.status(403).json({ error: "You don't have permission to modify this playlist", status: "error" });
    }

    // Remove the song
    const result = await collection.updateOne(
      {
        _id: new mongodb.ObjectId(id),
        createdBy: req.userId,
      },
      {
        $pull: {
          songs: { title: { $regex: `^${song.trim()}$`, $options: "i" } },
        },
      }
    );

    console.log("Update result:", result); 

    if (result.matchedCount === 0) {
      return res.status(404).json({ error: "Playlist not found or you don't have permission", status: "error" });
    }

    if (result.modifiedCount === 0) {
      return res.status(400).json({ error: "Song not found in playlist", status: "error" });
    }

    // Fetch the updated playlist
    const updatedPlaylist = await collection.findOne({ _id: new mongodb.ObjectId(id) });
    res.status(200).json({ message: "Song removed from playlist", playlist: updatedPlaylist });
  } catch (error) {
    console.error("Remove song error:", error);
    return res.status(500).json({ error: error.message, status: "error" });
  }
};


// @desc   Get all playlists
// @route  GET /api/v1/playlist/
// @access Private
export const getPlaylists = async (req, res) => {
  try {

    const db = conn.db("music_streaming");
    const collection = db.collection("playlists");
    const playlists = await collection
      .find({ createdBy: req.userId })
      .toArray();
    if (playlists.length === 0) {
      res.status(404);
      throw new Error("No playlists found");
    }
    res.status(200).json({ playlists });
  } catch (error) {
    console.log(error.message);
    return res.status(500).json({ error: error.message, status: "error" });
  }
};

// @desc   Get a playlist
// @route  GET /api/v1/playlist/:id
// @access Private
export const getPlaylist = async (req, res) => {
  try {

    const db = conn.db("music_streaming");
    const collection = db.collection("playlists");

    const playlist = await collection.findOne({
      _id: new mongodb.ObjectId(req.params.id),
    });
    if (playlist) {
      return res.status(200).json({ playlist });
    } else throw new Error("Error getting playlist");
  } catch (error) {
    console.log(error);
    return res.status(500).json({ error: error.message, status: "error" });
  }
};
