// // This component is used to display the song card in the home page and the playlist page. The song card is used to display the song name, artist name, and the options to play, add to queue, add to playlist, and delete the song. The song card is also used to play the song when the user clicks on the song card.

// //Importing libries
// import React from "react";
// import { useContext, useState, useRef } from "react";
// import axios from "axios";
// import { decodeToken } from "react-jwt";
// import {  useNavigate } from "react-router-dom";

// //Importing context
// import { SongContext } from "../Context/SongContext";
// import { FetchContext } from "../Context/FetchContext";
// import { QueueContext } from "../Context/QueueContex";

// //Importing icons
// import { SlOptionsVertical } from "react-icons/sl";
// import { MdDeleteOutline,MdOutlinePlaylistAdd,MdQueuePlayNext} from 'react-icons/md'
// import musicbg from "../assets/musicbg.jpg";


// const SongCard = ({ title, artistName, songSrc, userId, songId, file }) => {

//   // Using context
//   const { song, audio, __URL__ } = useContext(SongContext);
//   const { setFetchSong} = useContext(FetchContext);
//   const {dispatchQueue,dispatchList} = useContext(QueueContext)
//   const navigate = useNavigate(); // Used to navigate to the playlist page

//   const token = localStorage.getItem("access_token");
//   let decoded;
//   if(token) {decoded = decodeToken(token)};

//   const [showOptions, setShowOptions] = useState(false);

//   // Display the options
//   const displayOptions = () => {
//     setShowOptions((prev) => !prev);
//   };

//   // Play the song when the user clicks on the song card
//   const handlePlay = () => {
//     song.setSongName(title);
//     song.setArtistName(artistName);
//     song.setSongUrl(`${__URL__}/api/v1/stream/${songSrc}`);
//     audio.src = `${__URL__}/api/v1/stream/${songSrc}`;
//     audio.load();
//     audio.play();
//     song.setIsPlaying(true)
//   };

//   const headers = {
//     "x-auth-token": localStorage.getItem("access_token"),
//   };
//   // Delete the song
//   const deleteSong = async () => {
//     const { data,status } = await axios.delete(
//       `${__URL__}/api/v1/song/delete/${songId}?file=${file}`,
//       {
//         headers,
//       }
//     );
//     if(status == 200) setFetchSong(prev => !prev)
//   };
//   const handleDelete = () => {
//     confirm("Are you sure you want to delete this song?") && 
//     deleteSong();
//   };

//   // Add the song to the playlist
//   const handleAddToPlaylist = () => {
//     dispatchList({type:'ADD_SONG',payload:{title,artistName,songSrc}})
//     navigate("/playlists");
//   };

//   //Play the song next
//   const handlePlayNext = () => {
//     dispatchQueue({type:'ADD_TO_QUEUE',payload:{title,artistName,songSrc}})
//   };

//   return (
//     <div className="flex relative  bg-gray-800 text-white justify-between items-center border-b-[1px] p-2 lg:w-[70vw] mx-auto">
//       <div onClick={handlePlay} className="flex space-x-5 cursor-pointer">
//         <img src={musicbg} alt="" className="w-16" />
//         <div className="text-sm lg:text-lg">
//           <div>{title}</div>
//           <div>{artistName}</div>
//         </div>
//       </div>

//       {/* <---------------------------Desktop Options-------------------------> */}
//       <div className="hidden lg:flex justify-start items-center p-2 space-x-5">
//             <button onClick={handleAddToPlaylist}><MdOutlinePlaylistAdd size={30}/></button>
//             <button><MdQueuePlayNext size={25}/></button>
//             {
//               // if user is the owner of the song then show the delete option
//               decoded == null ?<> </>:( decoded.id === userId)?(
//                 <button onClick={handleDelete} className=" ">
//                   <MdDeleteOutline size={25}/>
//                 </button>
//               ):(<></>)
//             }
//           </div>
//       {/* <---------------------------Mobile Options-------------------------> */}
//       <div
//         onClick={displayOptions}
//         onMouseOut={() => setShowOptions(false)}
//         className="relative block lg:hidden"
//       >
//         <SlOptionsVertical size={15} />
//       </div>
//       {showOptions && (
//         <div className="absolute right-0 z-10 w-36 bg-gray-900 ">
//           <ul className="flex justify-start flex-col items-start space-y-2 p-2">
//             <button onClick={handleAddToPlaylist}>Add to playlist</button>
//             <button onClick={handlePlayNext}>play next</button>
//             {
//               // if user is the owner of the song then show the delete option
//               decoded == null ?<> </>:( decoded.id === userId)?(
//                 <button onClick={handleDelete} className=" ">
//                   Delete
//                 </button>
//               ):(<></>)
//             }
//           </ul>
//         </div>
//       )}
//     </div>
//   );
// };

// export default SongCard;




// import React, { useContext, useState } from "react";
// import axios from "axios";
// import { decodeToken } from "react-jwt";
// import { useNavigate } from "react-router-dom";
// import { SongContext } from "../Context/SongContext";
// import { FetchContext } from "../Context/FetchContext";
// import { QueueContext } from "../Context/QueueContex";
// import { SlOptionsVertical } from "react-icons/sl";
// import { MdDeleteOutline, MdOutlinePlaylistAdd, MdQueuePlayNext } from "react-icons/md";
// import musicbg from "../assets/musicbg.jpg";

// const SongCard = ({ title, artistName, songSrc, userId, songId, file }) => {
//   const { song, audio, __URL__ } = useContext(SongContext);
//   const { setFetchSong } = useContext(FetchContext);
//   const { dispatchQueue, dispatchList } = useContext(QueueContext);
//   const navigate = useNavigate();
//   const token = localStorage.getItem("access_token");
//   let decoded = token ? decodeToken(token) : null;
//   const [showOptions, setShowOptions] = useState(false);

//   const displayOptions = () => setShowOptions((prev) => !prev);

//   const handlePlay = () => {
//     song.setSongName(title);
//     song.setArtistName(artistName);
//     song.setSongUrl(`${__URL__}/api/v1/stream/${songSrc}`);
//     audio.src = `${__URL__}/api/v1/stream/${songSrc}`;
//     audio.load();
//     audio.play();
//     song.setIsPlaying(true);
//   };

//   const headers = { "x-auth-token": localStorage.getItem("access_token") };

//   const deleteSong = async () => {
//     const { data, status } = await axios.delete(
//       `${__URL__}/api/v1/song/delete/${songId}?file=${file}`,
//       { headers }
//     );
//     if (status === 200) setFetchSong((prev) => !prev);
//   };

//   const handleDelete = () => {
//     if (confirm("Are you sure you want to delete this song?")) deleteSong();
//   };

//   const handleAddToPlaylist = () => {
//     dispatchList({ type: "ADD_SONG", payload: { title, artistName, songSrc } });
//     navigate("/playlists");
//   };

//   const handlePlayNext = () => {
//     dispatchQueue({ type: "ADD_TO_QUEUE", payload: { title, artistName, songSrc } });
//   };

//   return (
//     <div className="card flex justify-between items-center p-4 mb-2 max-w-3xl mx-auto">
//       <div onClick={handlePlay} className="flex items-center space-x-4 cursor-pointer">
//         <img src={musicbg} alt="Song cover" className="w-16 h-16 rounded-md object-cover" />
//         <div>
//           <h3 className="text-lg font-medium">{title}</h3>
//           <p className="text-sm text-gray-400">{artistName}</p>
//         </div>
//       </div>
//       <div className="flex items-center space-x-4">
//         <div className="hidden lg:flex space-x-3">
//           <button onClick={handleAddToPlaylist} title="Add to Playlist">
//             <MdOutlinePlaylistAdd size={24} className="text-gray-300 hover:text-white" />
//           </button>
//           <button onClick={handlePlayNext} title="Play Next">
//             <MdQueuePlayNext size={24} className="text-gray-300 hover:text-white" />
//           </button>
//           {decoded && decoded.id === userId && (
//             <button onClick={handleDelete} title="Delete Song">
//               <MdDeleteOutline size={24} className="text-gray-300 hover:text-white" />
//             </button>
//           )}
//         </div>
//         <div className="lg:hidden relative">
//           <button onClick={displayOptions}>
//             <SlOptionsVertical size={20} className="text-gray-300" />
//           </button>
//           {showOptions && (
//             <div className="absolute right-0 mt-2 w-40 bg-gray-800 rounded-md shadow-lg z-10">
//               <ul className="py-2 text-sm">
//                 <li>
//                   <button onClick={handleAddToPlaylist} className="block px-4 py-2 hover:bg-gray-700 w-full text-left">
//                     Add to Playlist
//                   </button>
//                 </li>
//                 <li>
//                   <button onClick={handlePlayNext} className="block px-4 py-2 hover:bg-gray-700 w-full text-left">
//                     Play Next
//                   </button>
//                 </li>
//                 {decoded && decoded.id === userId && (
//                   <li>
//                     <button onClick={handleDelete} className="block px-4 py-2 hover:bg-gray-700 w-full text-left">
//                       Delete
//                     </button>
//                   </li>
//                 )}
//               </ul>
//             </div>
//           )}
//         </div>
//       </div>
//     </div>
//   );
// };

// export default SongCard;






// import React, { useContext, useState } from "react";
// import axios from "axios";
// import { decodeToken } from "react-jwt";
// import { useNavigate } from "react-router-dom";
// import { SongContext } from "../Context/SongContext";
// import { FetchContext } from "../Context/FetchContext";
// import { QueueContext } from "../Context/QueueContex";
// import { SlOptionsVertical } from "react-icons/sl";
// import { MdDeleteOutline, MdOutlinePlaylistAdd, MdQueuePlayNext } from "react-icons/md";
// import musicbg from "../assets/musicbg.jpg";

// const SongCard = ({ title, artistName, songSrc, userId, songId, file }) => {
//   const { song, audio } = useContext(SongContext);
//   const { setFetchSong } = useContext(FetchContext);
//   const { dispatchQueue, dispatchList } = useContext(QueueContext);
//   const navigate = useNavigate();
//   const token = localStorage.getItem("access_token");
//   let decoded = token ? decodeToken(token) : null;
//   const [showOptions, setShowOptions] = useState(false);

//   const displayOptions = () => setShowOptions((prev) => !prev);

//   const handlePlay = () => {
//     if (!songSrc) {
//       console.error("No songSrc provided for play");
//       return;
//     }
//     console.log("Playing song:", { title, artistName, songSrc });
//     song.setSongName(title);
//     song.setSongArtist(artistName || "Unknown Artist");
//     song.setSongUrl(`${song.__URL__}/api/v1/stream/${songSrc}`);
//     audio.src = `${song.__URL__}/api/v1/stream/${songSrc}`;
//     audio.load();
//     audio
//       .play()
//       .then(() => {
//         console.log("Playback started, artist:", artistName);
//         song.setIsPlaying(true);
//       })
//       .catch((error) => {
//         console.error("Play error:", error);
//       });
//   };

//   const headers = { "x-auth-token": localStorage.getItem("access_token") };

//   const deleteSong = async () => {
//     try {
//       const { data, status } = await axios.delete(
//         `${song.__URL__}/api/v1/song/delete/${songId}?file=${file}`,
//         { headers }
//       );
//       if (status === 200) setFetchSong((prev) => !prev);
//     } catch (error) {
//       console.error("Delete song error:", error);
//     }
//   };

//   const handleDelete = () => {
//     if (confirm("Are you sure you want to delete this song?")) deleteSong();
//   };

//   const handleAddToPlaylist = () => {
//     if (!songSrc) {
//       console.error("No songSrc for playlist");
//       return;
//     }
//     console.log("Adding to playlist:", { title, artistName, songSrc });
//     dispatchList({ type: "ADD_SONG", payload: { title, artistName: artistName || "Unknown Artist", songSrc } });
//     navigate("/playlists");
//   };

//   const handlePlayNext = () => {
//     if (!songSrc) {
//       console.error("No songSrc for queue");
//       return;
//     }
//     console.log("Adding to queue:", { title, artistName, songSrc });
//     dispatchQueue({ type: "ADD_TO_QUEUE", payload: { title, artistName: artistName || "Unknown Artist", songSrc } });
//   };

//   return (
//     <div className="card flex justify-between items-center p-4 mb-2 max-w-3xl mx-auto">
//       <div onClick={handlePlay} className="flex items-center space-x-4 cursor-pointer">
//         <img src={musicbg} alt="Song cover" className="w-16 h-16 rounded-md object-cover" />
//         <div>
//           <h3 className="text-lg font-medium">{title}</h3>
//           <p className="text-sm text-gray-400">{artistName || "Unknown Artist"}</p>
//         </div>
//       </div>
//       <div className="flex items-center space-x-4">
//         <div className="hidden lg:flex space-x-3">
//           <button onClick={handleAddToPlaylist} title="Add to Playlist">
//             <MdOutlinePlaylistAdd size={24} className="text-gray-300 hover:text-white" />
//           </button>
//           <button onClick={handlePlayNext} title="Play Next">
//             <MdQueuePlayNext size={24} className="text-gray-300 hover:text-white" />
//           </button>
//           {decoded && decoded.id === userId && (
//             <button onClick={handleDelete} title="Delete Song">
//               <MdDeleteOutline size={24} className="text-gray-300 hover:text-white" />
//             </button>
//           )}
//         </div>
//         <div className="lg:hidden relative">
//           <button onClick={displayOptions}>
//             <SlOptionsVertical size={20} className="text-gray-300" />
//           </button>
//           {showOptions && (
//             <div className="absolute right-0 mt-2 w-40 bg-gray-800 rounded-md shadow-lg z-10">
//               <ul className="py-2 text-sm">
//                 <li>
//                   <button onClick={handleAddToPlaylist} className="block px-4 py-2 hover:bg-gray-700 w-full text-left">
//                     Add to Playlist
//                   </button>
//                 </li>
//                 <li>
//                   <button onClick={handlePlayNext} className="block px-4 py-2 hover:bg-gray-700 w-full text-left">
//                     Play Next
//                   </button>
//                 </li>
//                 {decoded && decoded.id === userId && (
//                   <li>
//                     <button onClick={handleDelete} className="block px-4 py-2 hover:bg-gray-700 w-full text-left">
//                       Delete
//                     </button>
//                   </li>
//                 )}
//               </ul>
//             </div>
//           )}
//         </div>
//       </div>
//     </div>
//   );
// };

// export default SongCard;



// import React, { useContext, useState } from "react";
// import axios from "axios";
// import { decodeToken } from "react-jwt";
// import { useNavigate } from "react-router-dom";
// import { SongContext } from "../Context/SongContext";
// import { FetchContext } from "../Context/FetchContext";
// import { QueueContext } from "../Context/QueueContex";
// import { SlOptionsVertical } from "react-icons/sl";
// import { MdDeleteOutline, MdOutlinePlaylistAdd, MdQueuePlayNext } from "react-icons/md";
// import musicbg from "../assets/musicbg.jpg";

// const SongCard = ({ title, artistName, songSrc, userId, songId, file }) => {
//   const { song, audio, __URL__ } = useContext(SongContext);
//   const { setFetchSong } = useContext(FetchContext);
//   const { dispatchQueue, dispatchList } = useContext(QueueContext);
//   const navigate = useNavigate();
//   const token = localStorage.getItem("access_token");
//   let decoded = token ? decodeToken(token) : null;
//   const [showOptions, setShowOptions] = useState(false);

//   const displayOptions = () => setShowOptions((prev) => !prev);

//   const handlePlay = () => {
//     if (!songSrc) {
//       console.error("No songSrc provided for play");
//       return;
//     }
//     console.log("Playing song:", { title, artistName, songSrc });
//     song.setSongName(title);
//     song.setSongArtist(artistName); // Fixed typo: setArtistName -> setSongArtist
//     song.setSongUrl(`${__URL__}/api/v1/stream/${songSrc}`);
//     audio.src = `${__URL__}/api/v1/stream/${songSrc}`;
//     audio.load();
//     audio
//       .play()
//       .then(() => {
//         console.log("Playback started");
//         song.setIsPlaying(true);
//       })
//       .catch((error) => {
//         console.error("Play error:", error);
//       });
//   };

//   const headers = { "x-auth-token": localStorage.getItem("access_token") };

//   const deleteSong = async () => {
//     try {
//       const { data, status } = await axios.delete(
//         `${__URL__}/api/v1/song/delete/${songId}?file=${file}`,
//         { headers }
//       );
//       if (status === 200) setFetchSong((prev) => !prev);
//     } catch (error) {
//       console.error("Delete song error:", error);
//     }
//   };

//   const handleDelete = () => {
//     if (confirm("Are you sure you want to delete this song?")) deleteSong();
//   };

//   const handleAddToPlaylist = () => {
//     if (!songSrc) {
//       console.error("No songSrc for playlist");
//       return;
//     }
//     console.log("Adding to playlist:", { title, artistName, songSrc });
//     dispatchList({ type: "ADD_SONG", payload: { title, artistName, songSrc } });
//     navigate("/playlists");
//   };

//   const handlePlayNext = () => {
//     if (!songSrc) {
//       console.error("No songSrc for queue");
//       return;
//     }
//     console.log("Adding to queue:", { title, artistName, songSrc });
//     dispatchQueue({ type: "ADD_TO_QUEUE", payload: { title, artistName, songSrc } });
//   };

//   return (
//     <div className="card flex justify-between items-center p-4 mb-2 max-w-3xl mx-auto">
//       <div onClick={handlePlay} className="flex items-center space-x-4 cursor-pointer">
//         <img src={musicbg} alt="Song cover" className="w-16 h-16 rounded-md object-cover" />
//         <div>
//           <h3 className="text-lg font-medium">{title}</h3>
//           <p className="text-sm text-gray-400">{artistName}</p>
//         </div>
//       </div>
//       <div className="flex items-center space-x-4">
//         <div className="hidden lg:flex space-x-3">
//           <button onClick={handleAddToPlaylist} title="Add to Playlist">
//             <MdOutlinePlaylistAdd size={24} className="text-gray-300 hover:text-white" />
//           </button>
//           <button onClick={handlePlayNext} title="Play Next">
//             <MdQueuePlayNext size={24} className="text-gray-300 hover:text-white" />
//           </button>
//           {decoded && decoded.id === userId && (
//             <button onClick={handleDelete} title="Delete Song">
//               <MdDeleteOutline size={24} className="text-gray-300 hover:text-white" />
//             </button>
//           )}
//         </div>
//         <div className="lg:hidden relative">
//           <button onClick={displayOptions}>
//             <SlOptionsVertical size={20} className="text-gray-300" />
//           </button>
//           {showOptions && (
//             <div className="absolute right-0 mt-2 w-40 bg-gray-800 rounded-md shadow-lg z-10">
//               <ul className="py-2 text-sm">
//                 <li>
//                   <button onClick={handleAddToPlaylist} className="block px-4 py-2 hover:bg-gray-700 w-full text-left">
//                     Add to Playlist
//                   </button>
//                 </li>
//                 <li>
//                   <button onClick={handlePlayNext} className="block px-4 py-2 hover:bg-gray-700 w-full text-left">
//                     Play Next
//                   </button>
//                 </li>
//                 {decoded && decoded.id === userId && (
//                   <li>
//                     <button onClick={handleDelete} className="block px-4 py-2 hover:bg-gray-700 w-full text-left">
//                       Delete
//                     </button>
//                   </li>
//                 )}
//               </ul>
//             </div>
//           )}
//         </div>
//       </div>
//     </div>
//   );
// };

// export default SongCard;



// import React, { useContext, useState } from "react";
// import axios from "axios";
// import { decodeToken } from "react-jwt";
// import { useNavigate } from "react-router-dom";
// import { SongContext } from "../Context/SongContext";
// import { FetchContext } from "../Context/FetchContext";
// import { QueueContext } from "../Context/QueueContex";
// import { SlOptionsVertical } from "react-icons/sl";
// import { MdDeleteOutline, MdOutlinePlaylistAdd, MdQueuePlayNext } from "react-icons/md";
// import musicbg from "../assets/musicbg.jpg";

// const SongCard = ({ title, artistName, songSrc, userId, songId, file }) => {
//   const { song, audio } = useContext(SongContext);
//   const { setFetchSong } = useContext(FetchContext);
//   const { dispatchQueue, dispatchList } = useContext(QueueContext);
//   const navigate = useNavigate();
//   const token = localStorage.getItem("access_token");
//   let decoded = token ? decodeToken(token) : null;
//   const [showOptions, setShowOptions] = useState(false);

//   const displayOptions = () => setShowOptions((prev) => !prev);

//   const handlePlay = () => {
//     if (!songSrc) {
//       console.error("No songSrc provided for play");
//       return;
//     }
//     console.log("Playing song:", { title, artistName, songSrc });
//     song.setSongName(title || "Unknown Title");
//     song.setSongArtist(artistName || "Unknown Artist");
//     song.setSongUrl(`${song.__URL__}/api/v1/stream/${songSrc}`);
//     audio.src = `${song.__URL__}/api/v1/stream/${songSrc}`;
//     audio.load();
//     audio
//       .play()
//       .then(() => {
//         console.log("Playback started, artist:", artistName);
//         song.setIsPlaying(true);
//       })
//       .catch((error) => {
//         console.error("Play error:", error);
//       });
//   };

//   const headers = { "x-auth-token": localStorage.getItem("access_token") };

//   const deleteSong = async () => {
//     try {
//       const { data, status } = await axios.delete(
//         `${song.__URL__}/api/v1/song/delete/${songId}?file=${file}`,
//         { headers }
//       );
//       if (status === 200) setFetchSong((prev) => !prev);
//     } catch (error) {
//       console.error("Delete song error:", error);
//     }
//   };

//   const handleDelete = () => {
//     if (confirm("Are you sure you want to delete this song?")) deleteSong();
//   };

//   const handleAddToPlaylist = () => {
//     if (!songSrc) {
//       console.error("No songSrc for playlist");
//       return;
//     }
//     console.log("Adding to playlist:", { title, artistName, songSrc });
//     dispatchList({
//       type: "ADD_SONG",
//       payload: { title: title || "Unknown Title", artistName: artistName || "Unknown Artist", songSrc },
//     });
//     navigate("/playlists");
//   };

//   const handlePlayNext = () => {
//     if (!songSrc) {
//       console.error("No songSrc for queue");
//       return;
//     }
//     console.log("Adding to queue:", { title, artistName, songSrc });
//     dispatchQueue({
//       type: "ADD_TO_QUEUE",
//       payload: { title: title || "Unknown Title", artistName: artistName || "Unknown Artist", songSrc },
//     });
//   };

//   return (
//     <div className="card flex justify-between items-center p-4 mb-2 max-w-3xl mx-auto">
//       <div onClick={handlePlay} className="flex items-center space-x-4 cursor-pointer">
//         <img src={musicbg} alt="Song cover" className="w-16 h-16 rounded-md object-cover" />
//         <div>
//           <h3 className="text-lg font-medium">{title || "Unknown Title"}</h3>
//           <p className="text-sm text-gray-400">{artistName || "Unknown Artist"}</p>
//         </div>
//       </div>
//       <div className="flex items-center space-x-4">
//         <div className="hidden lg:flex space-x-3">
//           <button onClick={handleAddToPlaylist} title="Add to Playlist">
//             <MdOutlinePlaylistAdd size={24} className="text-gray-300 hover:text-white" />
//           </button>
//           <button onClick={handlePlayNext} title="Play Next">
//             <MdQueuePlayNext size={24} className="text-gray-300 hover:text-white" />
//           </button>
//           {decoded && decoded.id === userId && (
//             <button onClick={handleDelete} title="Delete Song">
//               <MdDeleteOutline size={24} className="text-gray-300 hover:text-white" />
//             </button>
//           )}
//         </div>
//         <div className="lg:hidden relative">
//           <button onClick={displayOptions}>
//             <SlOptionsVertical size={20} className="text-gray-300" />
//           </button>
//           {showOptions && (
//             <div className="absolute right-0 mt-2 w-40 bg-gray-800 rounded-md shadow-lg z-10">
//               <ul className="py-2 text-sm">
//                 <li>
//                   <button onClick={handleAddToPlaylist} className="block px-4 py-2 hover:bg-gray-700 w-full text-left">
//                     Add to Playlist
//                   </button>
//                 </li>
//                 <li>
//                   <button onClick={handlePlayNext} className="block px-4 py-2 hover:bg-gray-700 w-full text-left">
//                     Play Next
//                   </button>
//                 </li>
//                 {decoded && decoded.id === userId && (
//                   <li>
//                     <button onClick={handleDelete} className="block px-4 py-2 hover:bg-gray-700 w-full text-left">
//                       Delete
//                     </button>
//                   </li>
//                 )}
//               </ul>
//             </div>
//           )}
//         </div>
//       </div>
//     </div>
//   );
// };

// export default SongCard;


// import React, { useContext, useState } from "react";
// import axios from "axios";
// import { decodeToken } from "react-jwt";
// import { useNavigate } from "react-router-dom";
// import { SongContext } from "../Context/SongContext";
// import { FetchContext } from "../Context/FetchContext";
// import { QueueContext } from "../Context/QueueContex";
// import { SlOptionsVertical } from "react-icons/sl";
// import { MdDeleteOutline, MdOutlinePlaylistAdd, MdQueuePlayNext } from "react-icons/md";
// import musicbg from "../assets/musicbg.jpg";

// const SongCard = ({ title, artistName, songSrc, userId, songId, file }) => {
//   const { song, audio } = useContext(SongContext);
//   const { setFetchSong } = useContext(FetchContext);
//   const { dispatchQueue, dispatchList } = useContext(QueueContext);
//   const navigate = useNavigate();
//   const token = localStorage.getItem("access_token");
//   let decoded = token ? decodeToken(token) : null;
//   const [showOptions, setShowOptions] = useState(false);

//   const displayOptions = () => setShowOptions((prev) => !prev);

//   const handlePlay = () => {
//     if (!songSrc) {
//       console.error("No songSrc provided for play");
//       return;
//     }
//     console.log("Playing song:", { title, artistName, songSrc });
//     song.setSongName(title || "Unknown Title");
//     song.setSongArtist(artistName || "Unknown Artist");
//     const newSongUrl = `${song.__URL__}/api/v1/stream/${songSrc}`;
//     song.setSongUrl(newSongUrl);
//     audio.src = newSongUrl;
//     audio.load();

//     // Timeout for slow server
//     const loadTimeout = setTimeout(() => {
//       console.error("Audio load timeout:", newSongUrl);
//     }, 5000);

//     const handleCanPlayThrough = () => {
//       clearTimeout(loadTimeout);
//       console.log("Audio ready, playing:", newSongUrl, "Artist:", artistName);
//       audio
//         .play()
//         .then(() => {
//           console.log("Playback started, artist:", artistName);
//           song.setIsPlaying(true);
//         })
//         .catch((error) => {
//           console.error("Play error:", error);
//         });
//       audio.removeEventListener("canplaythrough", handleCanPlayThrough);
//     };

//     audio.addEventListener("canplaythrough", handleCanPlayThrough);

//     audio.onerror = () => {
//       clearTimeout(loadTimeout);
//       console.error("Error loading audio:", newSongUrl);
//       audio.onerror = null;
//     };
//   };

//   const headers = { "x-auth-token": localStorage.getItem("access_token") };

//   const deleteSong = async () => {
//     try {
//       const { data, status } = await axios.delete(
//         `${song.__URL__}/api/v1/song/delete/${songId}?file=${file}`,
//         { headers }
//       );
//       if (status === 200) setFetchSong((prev) => !prev);
//     } catch (error) {
//       console.error("Delete song error:", error);
//     }
//   };

//   const handleDelete = () => {
//     if (confirm("Are you sure you want to delete this song?")) deleteSong();
//   };

//   const handleAddToPlaylist = () => {
//     if (!songSrc) {
//       console.error("No songSrc for playlist");
//       return;
//     }
//     console.log("Adding to playlist:", { title, artistName, songSrc });
//     dispatchList({
//       type: "ADD_SONG",
//       payload: { title: title || "Unknown Title", artistName: artistName || "Unknown Artist", songSrc },
//     });
//     navigate("/playlists");
//   };

//   const handlePlayNext = () => {
//     if (!songSrc) {
//       console.error("No songSrc for queue");
//       return;
//     }
//     console.log("Adding to queue:", { title, artistName, songSrc });
//     dispatchQueue({
//       type: "ADD_TO_QUEUE",
//       payload: { title: title || "Unknown Title", artistName: artistName || "Unknown Artist", songSrc },
//     });
//   };

//   return (
//     <div className="card flex justify-between items-center p-4 mb-2 max-w-3xl mx-auto">
//       <div onClick={handlePlay} className="flex items-center space-x-4 cursor-pointer">
//         <img src={musicbg} alt="Song cover" className="w-16 h-16 rounded-md object-cover" />
//         <div>
//           <h3 className="text-lg font-medium">{title || "Unknown Title"}</h3>
//           <p className="text-sm text-gray-400">{artistName || "Unknown Artist"}</p>
//         </div>
//       </div>
//       <div className="flex items-center space-x-4">
//         <div className="hidden lg:flex space-x-3">
//           <button onClick={handleAddToPlaylist} title="Add to Playlist">
//             <MdOutlinePlaylistAdd size={24} className="text-gray-300 hover:text-white" />
//           </button>
//           <button onClick={handlePlayNext} title="Play Next">
//             <MdQueuePlayNext size={24} className="text-gray-300 hover:text-white" />
//           </button>
//           {decoded && decoded.id === userId && (
//             <button onClick={handleDelete} title="Delete Song">
//               <MdDeleteOutline size={24} className="text-gray-300 hover:text-white" />
//             </button>
//           )}
//         </div>
//         <div className="lg:hidden relative">
//           <button onClick={displayOptions}>
//             <SlOptionsVertical size={20} className="text-gray-300" />
//           </button>
//           {showOptions && (
//             <div className="absolute right-0 mt-2 w-40 bg-gray-800 rounded-md shadow-lg z-10">
//               <ul className="py-2 text-sm">
//                 <li>
//                   <button onClick={handleAddToPlaylist} className="block px-4 py-2 hover:bg-gray-700 w-full text-left">
//                     Add to Playlist
//                   </button>
//                 </li>
//                 <li>
//                   <button onClick={handlePlayNext} className="block px-4 py-2 hover:bg-gray-700 w-full text-left">
//                     Play Next
//                   </button>
//                 </li>
//                 {decoded && decoded.id === userId && (
//                   <li>
//                     <button onClick={handleDelete} className="block px-4 py-2 hover:bg-gray-700 w-full text-left">
//                       Delete
//                     </button>
//                   </li>
//                 )}
//               </ul>
//             </div>
//           )}
//         </div>
//       </div>
//     </div>
//   );
// };

// export default SongCard;


// import React, { useContext, useState } from "react";
// import axios from "axios";
// import { decodeToken } from "react-jwt";
// import { useNavigate } from "react-router-dom";
// import { SongContext } from "../Context/SongContext";
// import { FetchContext } from "../Context/FetchContext";
// import { QueueContext } from "../Context/QueueContex";
// import { SlOptionsVertical } from "react-icons/sl";
// import { MdDeleteOutline, MdOutlinePlaylistAdd, MdQueuePlayNext } from "react-icons/md";
// import musicbg from "../assets/musicbg.jpg";

// const SongCard = ({ title, artistName, songSrc, userId, songId, file }) => {
//   const { song, audio } = useContext(SongContext);
//   const { setFetchSong } = useContext(FetchContext);
//   const { dispatchQueue, dispatchList } = useContext(QueueContext);
//   const navigate = useNavigate();
//   const token = localStorage.getItem("access_token");
//   let decoded = token ? decodeToken(token) : null;
//   const [showOptions, setShowOptions] = useState(false);

//   const displayOptions = () => setShowMenu((prev) => !prev);

//   const handlePlay = () => {
//     if (!songSrc) {
//       console.error("No songSrc provided for play");
//       return;
//     }
//     console.log("Playing song:", { title, artistName, songSrc });
//     song.setSongName(title || "Unknown Title");
//     song.setSongArtist(artistName || "Unknown Artist");
//     const newSongUrl = `${song.__URL__}/api/v1/stream/${songSrc}`;
//     song.setSongUrl(newSongUrl);
//     audio.src = newSongUrl;
//     audio.load();

//     // Timeout for slow server
//     const loadTimeout = setTimeout(() => {
//       console.error("Audio load timeout:", newSongUrl);
//     }, 5000);

//     const handleCanPlayThrough = () => {
//       clearTimeout(loadTimeout);
//       console.log("Audio ready, playing:", newSongUrl, "Artist:", artistName);
//       audio
//         .play()
//         .then(() => {
//           console.log("Playback started, artist:", artistName);
//           song.setIsPlaying(true);
//         })
//         .catch((error) => {
//           console.error("Play error:", error);
//         });
//       audio.removeEventListener("canplaythrough", handleCanPlayThrough);
//     };

//     audio.addEventListener("canplaythrough", handleCanPlayThrough);

//     audio.onerror = () => {
//       clearTimeout(loadTimeout);
//       console.error("Error loading audio:", newSongUrl);
//       audio.onerror = null;
//     };
//   };

//   const headers = { "x-auth-token": localStorage.getItem("access_token") };

//   const deleteSong = async () => {
//     try {
//       const { data, status } = await axios.delete(
//         `${song.__URL__}/api/v1/song/delete/${songId}?file=${file}`,
//         { headers }
//       );
//       if (status === 200) setFetchSong((prev) => !prev);
//     } catch (error) {
//       console.error("Delete song error:", error);
//     }
//   };

//   const handleDelete = () => {
//     if (confirm("Are you sure you want to delete this song?")) deleteSong();
//   };

//   const handleAddToPlaylist = () => {
//     if (!songSrc) {
//       console.error("No songSrc for playlist");
//       return;
//     }
//     console.log("Adding to playlist:", { title, artistName, songSrc });
//     dispatchList({
//       type: "ADD_SONG",
//       payload: { title: title || "Unknown Title", artistName: artistName || "Unknown Artist", songSrc },
//     });
//     navigate("/playlists");
//   };

//   const handlePlayNext = () => {
//     if (!songSrc) {
//       console.error("No songSrc for queue");
//       return;
//     }
//     console.log("Adding to queue:", { title, artistName, songSrc });
//     dispatchQueue({
//       type: "ADD_TO_QUEUE",
//       payload: { title: title || "Unknown Title", artistName: artistName || "Unknown Artist", songSrc },
//     });
//   };

//   return (
//     <div className="card flex justify-between items-center p-4 mb-2 max-w-3xl mx-auto">
//       <div onClick={handlePlay} className="flex items-center space-x-4 cursor-pointer">
//         <img src={musicbg} alt="Song cover" className="w-16 h-16 rounded-md object-cover" />
//         <div>
//           <h3 className="text-lg font-medium">{title || "Unknown Title"}</h3>
//           <p className="text-sm text-gray-400">{artistName || "Unknown Artist"}</p>
//         </div>
//       </div>
//       <div className="flex items-center space-x-4">
//         <div className="hidden lg:flex space-x-3">
//           <button onClick={handleAddToPlaylist} title="Add to Playlist">
//             <MdOutlinePlaylistAdd size={24} className="text-gray-300 hover:text-white" />
//           </button>
//           <button onClick={handlePlayNext} title="Play Next">
//             <MdQueuePlayNext size={24} className="text-gray-300 hover:text-white" />
//           </button>
//           {decoded && decoded.id === userId && (
//             <button onClick={handleDelete} title="Delete Song">
//               <MdDeleteOutline size={24} className="text-gray-300 hover:text-white" />
//             </button>
//           )}
//         </div>
//         <div className="lg:hidden relative">
//           <button onClick={displayOptions}>
//             <SlOptionsVertical size={20} className="text-gray-300" />
//           </button>
//           {showOptions && (
//             <div className="absolute right-0 mt-2 w-40 bg-gray-800 rounded-md shadow-lg z-10">
//               <ul className="py-2 text-sm">
//                 <li>
//                   <button onClick={handleAddToPlaylist} className="block px-4 py-2 hover:bg-gray-700 w-full text-left">
//                     Add to Playlist
//                   </button>
//                 </li>
//                 <li>
//                   <button onClick={handlePlayNext} className="block px-4 py-2 hover:bg-gray-700 w-full text-left">
//                     Play Next
//                   </button>
//                 </li>
//                 {decoded && decoded.id === userId && (
//                   <li>
//                     <button onClick={handleDelete} className="block px-4 py-2 hover:bg-gray-700 w-full text-left">
//                       Delete
//                     </button>
//                   </li>
//                 )}
//               </ul>
//             </div>
//           )}
//         </div>
//       </div>
//     </div>
//   );
// };

// export default SongCard;



import React, { useContext, useState } from "react";
import axios from "axios";
import { decodeToken } from "react-jwt";
import { useNavigate } from "react-router-dom";
import { SongContext } from "../Context/SongContext";
import { FetchContext } from "../Context/FetchContext";
import { QueueContext } from "../Context/QueueContex";
import { SlOptionsVertical } from "react-icons/sl";
import { MdDeleteOutline, MdOutlinePlaylistAdd, MdQueuePlayNext } from "react-icons/md";
import musicbg from "../assets/musicbg.jpg";

const SongCard = ({ title, artistName, songSrc, userId, songId, file }) => {
  const { song, audio, __URL__ } = useContext(SongContext);
  const { setFetchSong } = useContext(FetchContext);
  const { dispatchQueue, dispatchList } = useContext(QueueContext);
  const navigate = useNavigate();
  const token = localStorage.getItem("access_token");
  let decoded = token ? decodeToken(token) : null;
  const [showOptions, setShowOptions] = useState(false);

  const displayOptions = () => setShowOptions((prev) => !prev);

  const handlePlay = () => {
    if (!songSrc) {
      console.error("No songSrc provided for play");
      return;
    }
    console.log("Playing song:", { title, artistName, songSrc });
    song.setSongName(title);
    song.setSongArtist(artistName); // Fixed typo: setArtistName -> setSongArtist
    song.setSongUrl(`${__URL__}/api/v1/stream/${songSrc}`);
    audio.src = `${__URL__}/api/v1/stream/${songSrc}`;
    audio.load();
    audio
      .play()
      .then(() => {
        console.log("Playback started");
        song.setIsPlaying(true);
      })
      .catch((error) => {
        console.error("Play error:", error);
      });
  };

  const headers = { "x-auth-token": localStorage.getItem("access_token") };

  const deleteSong = async () => {
    try {
      const { data, status } = await axios.delete(
        `${__URL__}/api/v1/song/delete/${songId}?file=${file}`,
        { headers }
      );
      if (status === 200) setFetchSong((prev) => !prev);
    } catch (error) {
      console.error("Delete song error:", error);
    }
  };

  const handleDelete = () => {
    if (confirm("Are you sure you want to delete this song?")) deleteSong();
  };

  const handleAddToPlaylist = () => {
    if (!songSrc) {
      console.error("No songSrc for playlist");
      return;
    }
    console.log("Adding to playlist:", { title, artistName, songSrc });
    dispatchList({ type: "ADD_SONG", payload: { title, artistName, songSrc } });
    navigate("/playlists");
  };

  const handlePlayNext = () => {
    if (!songSrc) {
      console.error("No songSrc for queue");
      return;
    }
    console.log("Adding to queue:", { title, artistName, songSrc });
    dispatchQueue({ type: "ADD_TO_QUEUE", payload: { title, artistName, songSrc } });
  };

  return (
    <div className="card flex justify-between items-center p-4 mb-2 max-w-3xl mx-auto">
      <div onClick={handlePlay} className="flex items-center space-x-4 cursor-pointer">
        <img src={musicbg} alt="Song cover" className="w-16 h-16 rounded-md object-cover" />
        <div>
          <h3 className="text-lg font-medium">{title}</h3>
          <p className="text-sm text-gray-400">{artistName}</p>
        </div>
      </div>
      <div className="flex items-center space-x-4">
        <div className="hidden lg:flex space-x-3">
          <button onClick={handleAddToPlaylist} title="Add to Playlist">
            <MdOutlinePlaylistAdd size={24} className="text-gray-300 hover:text-white" />
          </button>
          <button onClick={handlePlayNext} title="Play Next">
            <MdQueuePlayNext size={24} className="text-gray-300 hover:text-white" />
          </button>
          {decoded && decoded.id === userId && (
            <button onClick={handleDelete} title="Delete Song">
              <MdDeleteOutline size={24} className="text-gray-300 hover:text-white" />
            </button>
          )}
        </div>
        <div className="lg:hidden relative">
          <button onClick={displayOptions}>
            <SlOptionsVertical size={20} className="text-gray-300" />
          </button>
          {showOptions && (
            <div className="absolute right-0 mt-2 w-40 bg-gray-800 rounded-md shadow-lg z-10">
              <ul className="py-2 text-sm">
                <li>
                  <button onClick={handleAddToPlaylist} className="block px-4 py-2 hover:bg-gray-700 w-full text-left">
                    Add to Playlist
                  </button>
                </li>
                <li>
                  <button onClick={handlePlayNext} className="block px-4 py-2 hover:bg-gray-700 w-full text-left">
                    Play Next
                  </button>
                </li>
                {decoded && decoded.id === userId && (
                  <li>
                    <button onClick={handleDelete} className="block px-4 py-2 hover:bg-gray-700 w-full text-left">
                      Delete
                    </button>
                  </li>
                )}
              </ul>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default SongCard;