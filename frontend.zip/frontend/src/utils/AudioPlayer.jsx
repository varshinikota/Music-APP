// import React, { useState, useEffect, useRef, useContext } from "react";
// import stereo from "../assets/stereo.jpg";
// import { SongContext } from "../Context/SongContext";

// import { CiPlay1, CiPause1 } from "react-icons/ci";
// import { FiSkipBack, FiSkipForward } from "react-icons/fi";

// const AudioPlayer = () => {
//   const { song, audio,  } = useContext(SongContext);
 

//   const [duration, setDuration] = useState(0);
//   const [currentTime, setCurrentTime] = useState(0);

//   const progressBar = useRef();
 
//   useEffect(() => {
//     audio.addEventListener("loadedmetadata", () => {
//       setDuration(audio.duration);
//       progressBar.current.max = audio.duration;
//       console.log(progressBar)
//       console.log(audio)
//     });
//     audio.addEventListener("timeupdate", () => {
      
//       setCurrentTime(audio.currentTime);
//       progressBar.current.value = `${
//         (audio.currentTime / audio.duration) * 100
//       }%`;
//     });
//   }, [audio.src]);

//   // Toggle play/pause
//   const togglePlayPause = () => {
//     if (song.songUrl == "") return;
//     if (audio.paused) audio.play();
//     else audio.pause();
//     song.setIsPlaying(!song.isPlaying);
//   };

//   // Calculate time
//   const calculateTime = (secs) => {
//     const minutes = Math.floor(secs / 60);
//     const returnedMinutes = minutes < 10 ? `0${minutes}` : `${minutes}`;
//     const seconds = Math.floor(secs % 60);
//     const returnedSeconds = seconds < 10 ? `0${seconds}` : `${seconds}`;
//     return `${returnedMinutes}:${returnedSeconds}`;
//   };

//   return (
//     <div
//     className="fixed flex justify-between items-center bottom-0 right-0 left-0 bg-gray-900 text-white px-3 lg:px-5 py-2 shadow-xl"
//   >
//       <div className="flex space-x-5">
//         <img src={stereo} alt="" className="rounded-lg w-12" />
//         <div>
//           <h3 className="text-lg">{song.songName}</h3>
//           <p className="text-sm">{song.songArtist}</p>
//         </div>
//       </div>

    
//       <div className="flex space-x-3 lg:space-x-5">
//         <button>
//           <FiSkipBack />
//         </button>
//         <button onClick={togglePlayPause}>
//           { song.isPlaying == true ? <CiPause1 /> : <CiPlay1 />}
//         </button>
//         <button>
//           <FiSkipForward />
//         </button>
//       </div>

//       <div className="hidden lg:flex space-x-5">
//         {/* <input
//           type="range"
//           min="0"
//           ref={progressBar}
//           defaultValue="0"
//           className=" "
//           step={"any"}
//         /> */}
//         <p>
//           {calculateTime(parseInt(currentTime))}/
//           {calculateTime(parseInt(duration))}
//         </p>
//       </div>
//     </div>
//   );
// };

// export default AudioPlayer;






// import React, { useState, useEffect, useRef, useContext } from "react";
// import stereo from "../assets/stereo.jpg";
// import { SongContext } from "../Context/SongContext";
// import { QueueContext } from "../Context/QueueContex";
// import { CiPlay1, CiPause1 } from "react-icons/ci";
// import { FiSkipBack, FiSkipForward } from "react-icons/fi";

// const AudioPlayer = () => {
//   const { song, audio } = useContext(SongContext);
//   const { queue, dispatchQueue } = useContext(QueueContext);
//   const [duration, setDuration] = useState(0);
//   const [currentTime, setCurrentTime] = useState(0);
//   const progressBar = useRef();

//   // Set up audio event listeners for duration and time updates
//   useEffect(() => {
//     audio.addEventListener("loadedmetadata", () => {
//       setDuration(audio.duration);
//       progressBar.current.max = audio.duration;
//     });
//     audio.addEventListener("timeupdate", () => {
//       setCurrentTime(audio.currentTime);
//       progressBar.current.value = audio.currentTime;
//     });

//     // Cleanup event listeners on component unmount
//     return () => {
//       audio.removeEventListener("loadedmetadata", () => {});
//       audio.removeEventListener("timeupdate", () => {});
//     };
//   }, [audio]);

//   // Toggle play/pause
//   const togglePlayPause = () => {
//     if (!song.songUrl) return;
//     if (audio.paused) {
//       audio.play();
//       song.setIsPlaying(true);
//     } else {
//       audio.pause();
//       song.setIsPlaying(false);
//     }
//   };

//   // Format time (mm:ss)
//   const calculateTime = (secs) => {
//     const minutes = Math.floor(secs / 60);
//     const returnedMinutes = minutes < 10 ? `0${minutes}` : `${minutes}`;
//     const seconds = Math.floor(secs % 60);
//     const returnedSeconds = seconds < 10 ? `0${seconds}` : `${seconds}`;
//     return `${returnedMinutes}:${returnedSeconds}`;
//   };

//   // Update audio progress when user drags the progress bar
//   const handleProgressChange = () => {
//     audio.currentTime = progressBar.current.value;
//     setCurrentTime(progressBar.current.value);
//   };

//   // Play the next song in the queue
//   const handleNextSong = () => {
//     if (queue.length === 0) return;
//     const nextSong = queue[0]; // Get the first song in the queue
//     audio.pause();
//     song.setSongName(nextSong.title);
//     song.setArtistName(nextSong.artistName);
//     song.setSongUrl(`${song.__URL__}/api/v1/stream/${nextSong.songSrc}`);
//     audio.src = `${song.__URL__}/api/v1/stream/${nextSong.songSrc}`;
//     audio.load();
//     audio.play();
//     song.setIsPlaying(true);
//     dispatchQueue({ type: "REMOVE_FROM_QUEUE", payload: nextSong }); // Remove played song
//   };

//   // Placeholder for previous song functionality
//   const handlePreviousSong = () => {
//     // Implement if needed (e.g., track history or replay previous song)
//     console.log("Previous song not implemented");
//   };

//   return (
//     <div className="audio-player fixed bottom-0 left-0 right-0 flex items-center justify-between px-4 py-3 max-w-7xl mx-auto">
//       {/* Song Info */}
//       <div className="flex items-center space-x-4">
//         <img
//           src={stereo}
//           alt="Song cover"
//           className="w-12 h-12 rounded-md object-cover"
//         />
//         <div>
//           <h3 className="text-base font-medium">
//             {song.songName || "No Song Playing"}
//           </h3>
//           <p className="text-sm text-gray-400">
//             {song.songArtist || "Unknown Artist"}
//           </p>
//         </div>
//       </div>

//       {/* Controls and Progress Bar */}
//       <div className="flex flex-col items-center space-y-2 flex-1 mx-4">
//         <div className="flex space-x-4">
//           <button
//             onClick={handlePreviousSong}
//             title="Previous Song"
//             className="text-gray-300 hover:text-white"
//           >
//             <FiSkipBack size={24} />
//           </button>
//           <button
//             onClick={togglePlayPause}
//             title={song.isPlaying ? "Pause" : "Play"}
//             className="text-gray-300 hover:text-white"
//           >
//             {song.isPlaying ? (
//               <CiPause1 size={28} />
//             ) : (
//               <CiPlay1 size={28} />
//             )}
//           </button>
//           <button
//             onClick={handleNextSong}
//             title="Next Song"
//             className="text-gray-300 hover:text-white"
//           >
//             <FiSkipForward size={24} />
//           </button>
//         </div>
//         <div className="flex items-center w-full space-x-3">
//           <span className="text-sm">{calculateTime(currentTime)}</span>
//           <input
//             type="range"
//             min="0"
//             max={duration}
//             value={currentTime}
//             onChange={handleProgressChange}
//             ref={progressBar}
//             className="progress-bar"
//           />
//           <span className="text-sm">{calculateTime(duration)}</span>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default AudioPlayer;





// import React, { useState, useEffect, useRef, useContext } from "react";
// import stereo from "../assets/stereo.jpg";
// import { SongContext } from "../Context/SongContext";
// import { QueueContext } from "../Context/QueueContex";
// import { CiPlay1, CiPause1 } from "react-icons/ci";
// import { FiSkipBack, FiSkipForward } from "react-icons/fi";

// const AudioPlayer = () => {
//   const { song, audio } = useContext(SongContext);
//   const { queue, dispatchQueue } = useContext(QueueContext);
//   const [duration, setDuration] = useState(0);
//   const [currentTime, setCurrentTime] = useState(0);
//   const progressBar = useRef();

//   // Set up audio event listeners for duration and time updates
//   useEffect(() => {
//     const handleLoadedMetadata = () => {
//       console.log("Metadata loaded, duration:", audio.duration);
//       setDuration(audio.duration);
//       progressBar.current.max = audio.duration;
//     };

//     const handleTimeUpdate = () => {
//       setCurrentTime(audio.currentTime);
//       progressBar.current.value = audio.currentTime;
//     };

//     audio.addEventListener("loadedmetadata", handleLoadedMetadata);
//     audio.addEventListener("timeupdate", handleTimeUpdate);

//     // Cleanup event listeners
//     return () => {
//       audio.removeEventListener("loadedmetadata", handleLoadedMetadata);
//       audio.removeEventListener("timeupdate", handleTimeUpdate);
//     };
//   }, [audio]);

//   // Toggle play/pause
//   const togglePlayPause = () => {
//     if (!song.songUrl) {
//       console.log("No song URL to play");
//       return;
//     }
//     if (audio.paused) {
//       console.log("Playing:", song.songUrl);
//       audio
//         .play()
//         .then(() => {
//           console.log("Playback started");
//           song.setIsPlaying(true);
//         })
//         .catch((error) => {
//           console.error("Play error:", error);
//         });
//     } else {
//       console.log("Pausing audio");
//       audio.pause();
//       song.setIsPlaying(false);
//     }
//   };

//   // Format time (mm:ss)
//   const calculateTime = (secs) => {
//     const minutes = Math.floor(secs / 60);
//     const returnedMinutes = minutes < 10 ? `0${minutes}` : `${minutes}`;
//     const seconds = Math.floor(secs % 60);
//     const returnedSeconds = seconds < 10 ? `0${seconds}` : `${seconds}`;
//     return `${returnedMinutes}:${returnedSeconds}`;
//   };

//   // Update audio progress when user drags the progress bar
//   const handleProgressChange = () => {
//     audio.currentTime = progressBar.current.value;
//     setCurrentTime(progressBar.current.value);
//   };

//   // Play the next song in the queue
//   const handleNextSong = () => {
//     console.log("Current queue:", queue);
//     if (queue.length === 0) {
//       console.log("Queue is empty");
//       song.setIsPlaying(false);
//       return;
//     }

//     const nextSong = queue[0];
//     console.log("Next song:", nextSong);

//     // Validate songSrc
//     if (!nextSong.songSrc) {
//       console.error("Invalid songSrc:", nextSong);
//       dispatchQueue({ type: "REMOVE_FROM_QUEUE", payload: nextSong });
//       handleNextSong(); // Try the next song
//       return;
//     }

//     const newSongUrl = `${song.__URL__}/api/v1/stream/${nextSong.songSrc}`;
//     console.log("Setting audio source:", newSongUrl);

//     audio.pause();
//     audio.src = ""; // Clear current source
//     song.setSongName(nextSong.title || "Unknown Title");
//     song.setSongArtist(nextSong.artistName || "Unknown Artist");
//     song.setSongUrl(newSongUrl);
//     audio.src = newSongUrl;
//     audio.load();

//     // Timeout for slow server
//     const loadTimeout = setTimeout(() => {
//       console.error("Audio load timeout:", newSongUrl);
//       dispatchQueue({ type: "REMOVE_FROM_QUEUE", payload: nextSong });
//       handleNextSong();
//     }, 5000);

//     const handleCanPlayThrough = () => {
//       clearTimeout(loadTimeout);
//       console.log("Audio ready, playing:", newSongUrl);
//       audio
//         .play()
//         .then(() => {
//           console.log("Playing next song:", nextSong.title);
//           song.setIsPlaying(true);
//           dispatchQueue({ type: "REMOVE_FROM_QUEUE", payload: nextSong });
//         })
//         .catch((error) => {
//           console.error("Playback error:", error);
//           song.setIsPlaying(false);
//           dispatchQueue({ type: "REMOVE_FROM_QUEUE", payload: nextSong });
//           handleNextSong();
//         });
//       audio.removeEventListener("canplaythrough", handleCanPlayThrough);
//     };

//     audio.addEventListener("canplaythrough", handleCanPlayThrough);

//     audio.onerror = () => {
//       clearTimeout(loadTimeout);
//       console.error("Error loading audio:", newSongUrl);
//       song.setIsPlaying(false);
//       dispatchQueue({ type: "REMOVE_FROM_QUEUE", payload: nextSong });
//       handleNextSong();
//       audio.onerror = null;
//     };
//   };

//   // Placeholder for previous song
//   const handlePreviousSong = () => {
//     console.log("Previous song not implemented");
//   };

//   return (
//     <div className="audio-player fixed bottom-0 left-0 right-0 flex items-center justify-between px-4 py-3 max-w-7xl mx-auto">
//       <div className="flex items-center space-x-4">
//         <img
//           src={stereo}
//           alt="Song cover"
//           className="w-12 h-12 rounded-md object-cover"
//         />
//         <div>
//           <h3 className="text-base font-medium">
//             {song.songName || "No Song Playing"}
//           </h3>
//           <p className="text-sm text-gray-400">
//             {song.songArtist || "Unknown Artist"}
//           </p>
//         </div>
//       </div>
//       <div className="flex flex-col items-center space-y-2 flex-1 mx-4">
//         <div className="flex space-x-4">
//           <button
//             onClick={handlePreviousSong}
//             title="Previous Song"
//             className="text-gray-300 hover:text-white"
//           >
//             <FiSkipBack size={24} />
//           </button>
//           <button
//             onClick={togglePlayPause}
//             title={song.isPlaying ? "Pause" : "Play"}
//             className="text-gray-300 hover:text-white"
//           >
//             {song.isPlaying ? (
//               <CiPause1 size={28} />
//             ) : (
//               <CiPlay1 size={28} />
//             )}
//           </button>
//           <button
//             onClick={handleNextSong}
//             title="Next Song"
//             className="text-gray-300 hover:text-white"
//           >
//             <FiSkipForward size={24} />
//           </button>
//         </div>
//         <div className="flex items-center w-full space-x-3">
//           <span className="text-sm">{calculateTime(currentTime)}</span>
//           <input
//             type="range"
//             min="0"
//             max={duration}
//             value={currentTime}
//             onChange={handleProgressChange}
//             ref={progressBar}
//             className="progress-bar"
//           />
//           <span className="text-sm">{calculateTime(duration)}</span>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default AudioPlayer;




import React, { useState, useEffect, useRef, useContext } from "react";
import stereo from "../assets/stereo.jpg";
import { SongContext } from "../Context/SongContext";
import { QueueContext } from "../Context/QueueContex";
import { CiPlay1, CiPause1 } from "react-icons/ci";
import { FiSkipBack, FiSkipForward } from "react-icons/fi";

const AudioPlayer = () => {
  const { song, audio } = useContext(SongContext);
  const { queue, dispatchQueue } = useContext(QueueContext);
  const [duration, setDuration] = useState(0);
  const [currentTime, setCurrentTime] = useState(0);
  const progressBar = useRef();

  useEffect(() => {
    const handleLoadedMetadata = () => {
      console.log("Metadata loaded, duration:", audio.duration);
      setDuration(audio.duration);
      progressBar.current.max = audio.duration;
    };

    const handleTimeUpdate = () => {
      setCurrentTime(audio.currentTime);
      progressBar.current.value = audio.currentTime;
    };

    audio.addEventListener("loadedmetadata", handleLoadedMetadata);
    audio.addEventListener("timeupdate", handleTimeUpdate);

    return () => {
      audio.removeEventListener("loadedmetadata", handleLoadedMetadata);
      audio.removeEventListener("timeupdate", handleTimeUpdate);
    };
  }, [audio]);

  const togglePlayPause = () => {
    if (!song.songUrl) {
      console.log("No song URL to play");
      return;
    }
    if (audio.paused) {
      console.log("Playing:", song.songUrl, "Artist:", song.songArtist);
      audio
        .play()
        .then(() => {
          console.log("Playback started, artist:", song.songArtist);
          song.setIsPlaying(true);
        })
        .catch((error) => {
          console.error("Play error:", error);
        });
    } else {
      console.log("Pausing audio, artist:", song.songArtist);
      audio.pause();
      song.setIsPlaying(false);
    }
  };

  const calculateTime = (secs) => {
    const minutes = Math.floor(secs / 60);
    const returnedMinutes = minutes < 10 ? `0${minutes}` : `${minutes}`;
    const seconds = Math.floor(secs % 60);
    const returnedSeconds = seconds < 10 ? `0${seconds}` : `${seconds}`;
    return `${returnedMinutes}:${returnedSeconds}`;
  };

  const handleProgressChange = () => {
    audio.currentTime = progressBar.current.value;
    setCurrentTime(progressBar.current.value);
  };

  const handleNextSong = () => {
    console.log("Current queue:", queue);
    if (queue.length === 0) {
      console.log("Queue is empty");
      song.setIsPlaying(false);
      return;
    }

    const nextSong = queue[0];
    console.log("Next song:", nextSong);

    if (!nextSong.songSrc) {
      console.error("Invalid songSrc:", nextSong);
      dispatchQueue({ type: "REMOVE_FROM_QUEUE", payload: nextSong });
      handleNextSong();
      return;
    }

    const newSongUrl = `${song.__URL__}/api/v1/stream/${nextSong.songSrc}`;
    console.log("Setting audio source:", newSongUrl, "Artist:", nextSong.artistName);

    audio.pause();
    audio.src = "";
    song.setSongName(nextSong.title || "Unknown Title");
    song.setSongArtist(nextSong.artistName || "Unknown Artist");
    song.setSongUrl(newSongUrl);
    audio.src = newSongUrl;
    audio.load();

    const loadTimeout = setTimeout(() => {
      console.error("Audio load timeout:", newSongUrl);
      dispatchQueue({ type: "REMOVE_FROM_QUEUE", payload: nextSong });
      handleNextSong();
    }, 5000);

    const handleCanPlayThrough = () => {
      clearTimeout(loadTimeout);
      console.log("Audio ready, playing:", newSongUrl, "Artist:", nextSong.artistName);
      audio
        .play()
        .then(() => {
          console.log("Playing next song:", nextSong.title, "Artist:", nextSong.artistName);
          song.setIsPlaying(true);
          dispatchQueue({ type: "REMOVE_FROM_QUEUE", payload: nextSong });
        })
        .catch((error) => {
          console.error("Playback error:", error);
          song.setIsPlaying(false);
          dispatchQueue({ type: "REMOVE_FROM_QUEUE", payload: nextSong });
          handleNextSong();
        });
      audio.removeEventListener("canplaythrough", handleCanPlayThrough);
    };

    audio.addEventListener("canplaythrough", handleCanPlayThrough);

    audio.onerror = () => {
      clearTimeout(loadTimeout);
      console.error("Error loading audio:", newSongUrl);
      song.setIsPlaying(false);
      dispatchQueue({ type: "REMOVE_FROM_QUEUE", payload: nextSong });
      handleNextSong();
      audio.onerror = null;
    };
  };

  const handlePreviousSong = () => {
    console.log("Previous song not implemented");
  };

  return (
    <div className="audio-player fixed bottom-0 left-0 right-0 flex items-center justify-between px-4 py-3 max-w-7xl mx-auto">
      <div className="flex items-center space-x-4">
        <img
          src={stereo}
          alt="Song cover"
          className="w-12 h-12 rounded-md object-cover"
        />
        <div>
          <h3 className="text-base font-medium">
            {song.songName || "No Song Playing"}
          </h3>
          <p className="text-sm text-gray-400">
            {song.songArtist || "Unknown Artist"}
          </p>
        </div>
      </div>
      <div className="flex flex-col items-center space-y-2 flex-1 mx-4">
        <div className="flex space-x-4">
          <button
            onClick={handlePreviousSong}
            title="Previous Song"
            className="text-gray-300 hover:text-white"
          >
            <FiSkipBack size={24} />
          </button>
          <button
            onClick={togglePlayPause}
            title={song.isPlaying ? "Pause" : "Play"}
            className="text-gray-300 hover:text-white"
          >
            {song.isPlaying ? (
              <CiPause1 size={28} />
            ) : (
              <CiPlay1 size={28} />
            )}
          </button>
          <button
            onClick={handleNextSong}
            title="Next Song"
            className="text-gray-300 hover:text-white"
          >
            <FiSkipForward size={24} />
          </button>
        </div>
        <div className="flex items-center w-full space-x-3">
          <span className="text-sm">{calculateTime(currentTime)}</span>
          <input
            type="range"
            min="0"
            max={duration}
            value={currentTime}
            onChange={handleProgressChange}
            ref={progressBar}
            className="progress-bar"
          />
          <span className="text-sm">{calculateTime(duration)}</span>
        </div>
      </div>
    </div>
  );
};

export default AudioPlayer;