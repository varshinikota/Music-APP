import React, { useEffect, useState, useContext } from "react";
import axios from "axios";
import { useLocation, useNavigate } from "react-router-dom";
import SongCard from "../components/SongCard";
import { SidebarContext } from "../Context/SibebarContext";
import { FetchContext } from "../Context/FetchContext";
import { SongContext } from "../Context/SongContext";

const Search = () => {
  const { showMenu, setShowMenu } = useContext(SidebarContext);
  const { __URL__ } = useContext(SongContext);
  const { fetchSong } = useContext(FetchContext);
  const [songs, setSongs] = useState([]);
  const [loading, setLoading] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();

  const query = new URLSearchParams(location.search).get("query");

  useEffect(() => {
    if (showMenu) setShowMenu(false);

    const fetchSearchResults = async () => {
      try {
        if (!query) {
          setSongs([]);
          return;
        }

        setLoading(true);
        const headers = {
          "X-Auth-Token": localStorage.getItem("access_token"),
        };
        const { data } = await axios.get(
          `${__URL__}/api/v1/song/search?query=${encodeURIComponent(query)}`,
          { headers }
        );
        setSongs(data.songs);
        setLoading(false);
      } catch (error) {
        setLoading(false);
        console.error("Search error:", error);
        if (error.response?.status === 401) {
          localStorage.removeItem("access_token");
          navigate("/login");
        }
      }
    };

    fetchSearchResults();
  }, [query, fetchSong, __URL__, navigate, setShowMenu, showMenu]);

  return (
    <div className="bg-gray-900 p-5 space-y-2 min-h-screen text-white">
      <h2 className="text-2xl mb-4">Search Results for "{query}"</h2>
      {loading ? (
        <div>Loading...</div>
      ) : songs.length > 0 ? (
        songs.map((song) => (
          <SongCard
            key={song._id}
            title={song.title}
            artistName={song.artist}
            songSrc={song.song}
            userId={song.uploadedBy}
            songId={song._id}
            file={song.file}
          />
        ))
      ) : (
        <div>No songs found for "{query}"</div>
      )}
    </div>
  );
};

export default Search;
