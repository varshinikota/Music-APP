// import { createContext, useReducer } from "react";

// export const QueueContext = createContext();

// const addSongToQueue = (state, action) => {
//   switch (action.type) {
//     case "ADD_TO_QUEUE":
//       return [...state, action.payload];
//     case "REMOVE_FROM_QUEUE":
//       return state.filter((song) => song._id !== action.payload);
//     default:
//       return state;
//   }
// };

// const addSongToList = (state, action) => {
//   switch (action.type) {
//     case "ADD_SONG":
//       return [...state, action.payload];
//     case "REMOVE_SONG":
//       return state.filter((song) => song.title !== action.payload);
//     default:
//       return state;
//   }
// };

// export const QueueContextState = ({ children }) => {
//   const initialQueue = [
    
//   ];
//   const initialList = [];

//   const [queue, dispatchQueue] = useReducer(addSongToQueue, initialQueue);
//   const [list, dispatchList] = useReducer(addSongToList, initialList);

//   return (<QueueContext.Provider value={{list,queue,dispatchList,dispatchQueue}}>
//     {children}
//   </QueueContext.Provider>);
// };



// import { createContext, useReducer } from "react";

// export const QueueContext = createContext();

// const initialState = {
//   queue: [], // Songs in the queue: [{ title, artistName, songSrc }, ...]
//   list: [], // Songs for playlist selection: [{ title, artistName, songSrc }, ...]
//   currentIndex: -1, // Index of the currently playing song in the queue
// };

// const queueReducer = (state, action) => {
//   switch (action.type) {
//     case "ADD_TO_QUEUE":
//       return {
//         ...state,
//         queue: [...state.queue, action.payload],
//       };
//     case "ADD_SONG":
//       return {
//         ...state,
//         list: [...state.list, action.payload],
//       };
//     case "PLAY_NEXT":
//       if (state.currentIndex + 1 < state.queue.length) {
//         return {
//           ...state,
//           currentIndex: state.currentIndex + 1,
//         };
//       }
//       return state; // No next song
//     case "SET_CURRENT_SONG":
//       return {
//         ...state,
//         currentIndex: action.payload.index,
//         queue: action.payload.queue || state.queue,
//       };
//     case "CLEAR_QUEUE":
//       return {
//         ...state,
//         queue: [],
//         currentIndex: -1,
//       };
//     default:
//       return state;
//   }
// };

// export const QueueContextProvider = ({ children }) => {
//   const [state, dispatch] = useReducer(queueReducer, initialState);

//   return (
//     <QueueContext.Provider value={{ ...state, dispatchQueue: dispatch, dispatchList: dispatch }}>
//       {children}
//     </QueueContext.Provider>
//   );
// };






// import { createContext, useReducer } from "react";

// export const QueueContext = createContext();

// const addSongToQueue = (state, action) => {
//   switch (action.type) {
//     case "ADD_TO_QUEUE":
//       return [...state, action.payload];
//     case "REMOVE_FROM_QUEUE":
//       return state.filter((song) => song.songSrc !== action.payload.songSrc);
//     default:
//       return state;
//   }
// };

// const addSongToList = (state, action) => {
//   switch (action.type) {
//     case "ADD_SONG":
//       return [...state, action.payload];
//     case "REMOVE_SONG":
//       return state.filter((song) => song.title !== action.payload);
//     default:
//       return state;
//   }
// };

// export const QueueContextState = ({ children }) => {
//   const initialQueue = [];
//   const initialList = [];

//   const [queue, dispatchQueue] = useReducer(addSongToQueue, initialQueue);
//   const [list, dispatchList] = useReducer(addSongToList, initialList);

//   return (
//     <QueueContext.Provider value={{ list, queue, dispatchList, dispatchQueue }}>
//       {children}
//     </QueueContext.Provider>
//   );
// };






// import { createContext, useReducer } from "react";

// export const QueueContext = createContext();

// const addSongToQueue = (state, action) => {
//   switch (action.type) {
//     case "ADD_TO_QUEUE":
//       return [...state, action.payload];
//     case "REMOVE_FROM_QUEUE":
//       return state.filter((song) => song.songSrc !== action.payload.songSrc);
//     default:
//       return state;
//   }
// };

// const addSongToList = (state, action) => {
//   switch (action.type) {
//     case "ADD_SONG":
//       return [...state, action.payload];
//     case "REMOVE_SONG":
//       return state.filter((song) => song.songSrc !== action.payload.songSrc); // Changed to songSrc
//     default:
//       return state;
//   }
// };

// export const QueueContextState = ({ children }) => {
//   const initialQueue = [];
//   const initialList = [];

//   const [queue, dispatchQueue] = useReducer(addSongToQueue, initialQueue);
//   const [list, dispatchList] = useReducer(addSongToList, initialList);

//   return (
//     <QueueContext.Provider value={{ list, queue, dispatchList, dispatchQueue }}>
//       {children}
//     </QueueContext.Provider>
//   );
// };

// import { createContext, useReducer } from "react";

// export const QueueContext = createContext();

// const addSongToQueue = (state, action) => {
//   switch (action.type) {
//     case "ADD_TO_QUEUE":
//       return [...state, action.payload];
//     case "REMOVE_FROM_QUEUE":
//       return state.filter((song) => song.songSrc !== action.payload.songSrc);
//     default:
//       return state;
//   }
// };

// const addSongToList = (state, action) => {
//   switch (action.type) {
//     case "ADD_SONG":
//       return [...state, action.payload];
//     case "REMOVE_SONG":
//       return state.filter((song) => song.songSrc !== action.payload.songSrc);
//     default:
//       return state;
//   }
// };

// export const QueueContextState = ({ children }) => {
//   const initialQueue = [];
//   const initialList = [];

//   const [queue, dispatchQueue] = useReducer(addSongToQueue, initialQueue);
//   const [list, dispatchList] = useReducer(addSongToList, initialList);

//   return (
//     <QueueContext.Provider value={{ list, queue, dispatchList, dispatchQueue }}>
//       {children}
//     </QueueContext.Provider>
//   );
// };


import { createContext, useReducer } from "react";

export const QueueContext = createContext();

const addSongToQueue = (state, action) => {
  switch (action.type) {
    case "ADD_TO_QUEUE":
      return [...state, action.payload];
    case "REMOVE_FROM_QUEUE":
      return state.filter((song) => song.songSrc !== action.payload.songSrc);
    default:
      return state;
  }
};

const addSongToList = (state, action) => {
  switch (action.type) {
    case "ADD_SONG":
      return [...state, action.payload];
    case "REMOVE_SONG":
      return state.filter((song) => song.songSrc !== action.payload.songSrc); // Changed to songSrc
    default:
      return state;
  }
};

export const QueueContextState = ({ children }) => {
  const initialQueue = [];
  const initialList = [];

  const [queue, dispatchQueue] = useReducer(addSongToQueue, initialQueue);
  const [list, dispatchList] = useReducer(addSongToList, initialList);

  return (
    <QueueContext.Provider value={{ list, queue, dispatchList, dispatchQueue }}>
      {children}
    </QueueContext.Provider>
  );
};