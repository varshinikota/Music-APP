import { createContext, useState, useRef } from "react";

export const SongContext = createContext();

export const SongContextState = ({ children }) => {
  let __URL__;
  if(document.domain === "localhost"){
    __URL__ = "http://localhost:1337"
  }else{
    __URL__ = "https://music-player-app-backend-yq0c.onrender.com"
  }
  const audio = new Audio();
  const song = {
    songUrl: "",
    songName: "",
    songArtist: "",
    songAlbum: "",
    isPlaying: false,

    setSongUrl: (url) => {
      song.songUrl = url;
    },
    setSongName: (name) => {
      song.songName = name;
    },
    setArtistName: (name) => {
      song.songArtist = name;
    },
    setAlbumName: (name) => song.songAlbum = name,
    setIsPlaying : ( val )=>{
      song.isPlaying = val
    },
    
  };

  return <SongContext.Provider value={{audio,song,__URL__}}>{children}</SongContext.Provider>;
};



// import { createContext, useState } from "react";

// export const SongContext = createContext();

// export const SongContextState = ({ children }) => {
//   let __URL__;
//   if (document.domain === "localhost") {
//     __URL__ = "http://localhost:1337"; // Adjust to your backend port (e.g., 5000)
//   } else {
//     __URL__ = "https://music-player-app-backend-yq0c.onrender.com";
//   }

//   const [songUrl, setSongUrl] = useState("");
//   const [songName, setSongName] = useState("");
//   const [songArtist, setSongArtist] = useState("");
//   const [songAlbum, setSongAlbum] = useState("");
//   const [isPlaying, setIsPlaying] = useState(false);
//   const audio = new Audio();

//   const song = {
//     __URL__,
//     songUrl,
//     setSongUrl,
//     songName,
//     setSongName,
//     songArtist,
//     setSongArtist,
//     songAlbum,
//     setSongAlbum,
//     isPlaying,
//     setIsPlaying,
//   };

//   return <SongContext.Provider value={{ audio, song }}>{children}</SongContext.Provider>;
// };